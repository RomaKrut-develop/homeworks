spisok = 10
array = [17, 10, 14, 11, 9, 19, 15, 16, 18, 13]

for run in range(spisok-1):
    for i in range(spisok-1):
        if array[i] > array[i+1]:
            array[i], array[i+1] = array[i+1], array[i]
print(f"Temperatures in last mounth: {array}")