def sorting_students(students):
    n = len(students)
    for i in range(n):
        for j in range(0, n-i-1):
            if students[j]['average'] > students[j+1]['average']:
                students[j], students[j+1] = students[j+1], students[j]
    return students

students_list = [
    {'name': 'Mike', 'average': 24},
    {'name': 'Phillip', 'average': 67},
    {'name': 'Gordon', 'average': 79},
    {'name': 'Layla', 'average': 92}
]
sorted_students = sorting_students(students_list)
print("Sorted list with averge grades: ")
for student in sorted_students:
    print(f"{student['name']}: {student['average']}")