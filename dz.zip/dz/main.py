import time

start_time = time.time()

# Icon
print('                                                     ---------------')
print('                                                     | *  -  I  -  * |')
print('                           . - * find    everyting   |  I Pychrome I |    in   our    world * - .')
print('                                                     |    -  I  -    |')
print('                                                     ----------------')

debug_controller = 0
# Main Program
while True:
    def linear_search(arr, target):
        for i in range(len(arr)):
            if arr[i] == target:
                return i
        return - 1

    arr = ['C#', 'C++', 'Python', 'car', 'cat', 'food', 'hamster', 'dbg_pc_1', 'dbg_pc_0']
    target = input('                   Find everything! ')
    result = linear_search(arr, target)

    if result != -1:
        print('------------------------------')
        if debug_controller == 1:
            print(f"Find {target} in the array at index {result}")
        elif debug_controller == 0:
            print()
        if result == 1:
            print("C++ is a programming language!")
            print(' ')
            print('------------------------------')
        elif result == 2:
            print("Python is a programming language!")
            print(' ')
            print('------------------------------')
        elif result == 3:
            print('Car is a vehicle that can transfer people or cargo')
            print(' ')
            print('------------------------------')
        elif result == 4:
            print('Cat is a small, typically furry, carnivorous mammal')
            print(' ')
            print('------------------------------')
        elif result == 5:
            print('Food is any substance that is ingested to provide nutrition')
            print(' ')
            print('------------------------------')
        elif result == 6:
            print('Hamster is a small rodent that is often kept as a pet')
        elif result == 7:
            debug_controller += 1
            print('Index place display - on')
        elif result == 8:
            debug_controller -= 1
            print('Index place display - off')
    else:
        print(f"{target} dosent finded")

    end_time = time.time()
    print(f"Result fined for: {end_time - start_time} seconds")