import time
import os
from colorama import init, Fore, Style, Back
init()
# Start up animation
time.sleep(0.1)
print(Fore.LIGHTGREEN_EX + '                  .   .   .. * *---------------------')
time.sleep(0.1)
print('                     .  .. * **|    I------------I   |')
time.sleep(0.1)
print('                 .   .  .. * **|    | Pynthos XP+|   |')
time.sleep(0.1)
print('                     .  .. * **|    I____________I   |')
time.sleep(0.1)
print('                  .   .   .. * *---------------------' + Style.RESET_ALL)
print('                                                     ')
print('                                                     ')
print('                                                     ')
print('                                                     ')
print('                                                     ')
print('                                                     ')
print('                                                     ')
print('                                                     ')
print('                                                     ')
print('                                                     ')
print('                                                     ')
print('                                                     ')
print('                                                     ')
print('                                                     ')
print('CD-ROM Soft            All rights reserved')
print('                                                     ')
uname = os.getlogin()
print(Fore.GREEN +'Welcome, to Python version of Windows XP, ' + uname)
#Main OS
while True:
	time.sleep(0.4)
	time.sleep(0.2)
	print('Choose option:')
	time.sleep(0.2)
	print(Fore.LIGHTRED_EX + '1. Exit to main OS ' + Fore.GREEN + '2. Calculator ' + Fore.LIGHTBLUE_EX + '3. File manager' + Style.RESET_ALL + Fore.LIGHTGREEN_EX + ' 4. About' + Style.RESET_ALL + Fore.RED + ' 5. Shutdown PC')
	print(Fore.GREEN + '6. ColorTest' + Style.RESET_ALL)
	os_choose = int(input('Wait for input '))
	if os_choose == 2:
		time.sleep(0.2)
		print(Back.LIGHTBLUE_EX + '-----------------')
		print(Back.LIGHTBLUE_EX + '|Choose function|')
		print(Back.LIGHTBLUE_EX + ' ---------------' + Style.RESET_ALL)
		time.sleep(0.2)
		print('1. Addition 2. Subtraction 3. Multiplication 4. Division ' + Fore.RED + '0. Exit' + Style.RESET_ALL)
		calc_choose = int(input('Wait for input '))
		if calc_choose == 1:
			first_num = int(input('Wait for input: First number: '))
			sec_num = int(input('Wait for input: Second number: '))
			result = first_num + sec_num
			print(result)
		elif calc_choose == 2:
			first_num = int(input('Wait for input: First number: '))
			sec_num = int(input('Wait for input: Second number: '))
			result = first_num - sec_num
			print(result)
		elif calc_choose == 3:
			first_num = int(input('Wait for input: First number: '))
			sec_num = int(input('Wait for input: Second number: '))
			result = first_num * sec_num
			print(result)
		elif calc_choose == 4:
			first_num = int(input('Wait for input: First number: '))
			sec_num = int(input('Wait for input: Second number: '))
			result = first_num / sec_num
			print(result)
		elif calc_choose == 0:
			pass
		else:
			print('Critical Error: Unknown Function')
	elif os_choose == 3:
	#cod - create or delete
		print("Choose function:")
		print('0. Exit')
		print("1. Create file")
		print("2. Delete file")
		print(Fore.LIGHTWHITE_EX + "3. Help")
        
		cod_choose = int(input("Wait for input: choise:  "))
    # here, start of creating files.
		# creating files
		if cod_choose == 1:
			print('----------------')
			print('|Create new file|')
			print('----------------')
			file_name = input("Enter file name: ")
			print('1. Type 0 to make txt file 2. Type 1 to make python file 3. Type 2 to make bat file')
			file_format = int(input('Enter format: '))
			# main block of creating files
			if not file_format:
				print('Cannot create file without format')
				crash_path = os.path.join('Debug_Crashes', 'Format_crash.txt')
				with open(crash_path, 'w') as crash:
					crash.write('System critical crash happaned by: Error 40: User try to create file without format')
				break
			elif not file_name.strip():
				print('Cannot create file without name')
				crash_path = os.path.join('Debug_Crashes', 'Name_crash.txt')
				with open(crash_path, 'w') as crash:
					crash.write('System critical crash happaned by: Error 42: User enter empty name of file')
				break
			elif file_format == 2:
				file_name += '.py'
			elif not file_format == 1 or file_name == 2:
				file_name += '.txt'
				print(f'{file_name}, created with manual format: txt')
			print('----------------')
			file_cont = input("Enter information: ")
			print('----------------')
			file_path = os.path.join('Storage (P;)', file_name)
			with open(file_path, 'w') as file:
				file.write(file_cont)
				print("File created. Operation = 1")
				# end of main block creating files
		# deleting files
		elif cod_choose == 2:
			print('-------------')
			print('|Delete file |')
			print('-------------')
			import time
			time.sleep(0.3)
			print(Fore.LIGHTRED_EX + 'Attention! ' + Style.RESET_ALL + 'when you deleting files, you should entering format')
			time.sleep(0.3)
			print('Example: yourfile.txt')
			time.sleep(0.3)
			print("Without this, program don't delete your file")
			file_name = input("Enter file name: ")
			if not file_name.strip():
				print('Cannot delete file without name')
			if file_name == 'inf!.txt':
				print('Cannot delete inf!.txt')
				time.sleep(0.5)
				print('Error: Important.file-deleting.error')
				time.sleep(0.5)
				break
			elif file_name == 'sys42.gif':
				print('Cannot delete sys42!.gif')
				os.system('shutdown /s /t 0')
				break
			file_path = os.path.join('Storage (P;)', file_name)
			if os.path.exists(file_path):
				os.remove(file_path)
				print("File deleted. Operation = 1")
		if cod_choose == 0:
			pass
		elif cod_choose == 3:
			print('-------------')
			print('|    Help   |')
			print('-------------')
			time.sleep(0.3)
			print('This is a manual for begginers in tool for file creating tool Pythos XP')
			print('-----------------------------------------------------------------------')
			print(Fore.LIGHTBLUE_EX + "1. Main rules for formats'n'names" + Style.RESET_ALL)
			print('1.1 Avoiding errors:')
			print('1.1.1 Try formats and names correctly. You can get two errors: Name and Format one, if you try to create file without name or format.')
			print('                    ')
			print('1.2 Typing etiquette: ')
			print("1.2.1 Let's create files, without any strange, cruel and bad words.")

		else:
			print("This file doesn't exist. Operation = 0")
		
	elif os_choose == 4:
		print('                    ')
		print('Welcome to Pythos XP+')
		print('____________________')
		print('Pythris XP+ edition')
	elif os_choose == 5:
		os.system('shutdown /s /t 0')
	elif os_choose == 6:
		print(Fore.RED + '1. R' + Fore.YELLOW + 'a' + Fore.GREEN + 'i' + Fore.CYAN + 'n' + Fore.BLUE + 'b' + Fore.MAGENTA + 'o' + 'w' + 'Test' + Fore.RED + ' 2. R' + Fore.GREEN  + 'G' + Fore.BLUE + 'B ' + Style.RESET_ALL + Fore.LIGHTBLUE_EX + Back.BLUE + '3. Windows Logo' + Style.RESET_ALL)
		color_input = int(input('Wait for input: color_input: '))
		iteration = 30
		if color_input == 1:
			while iteration > 0:
				import time
				time.sleep(0.03)
				print(Back.RED + '                                 ')
				time.sleep(0.03)
				iteration -= 1
				print(Back.YELLOW + '                                 ')
				time.sleep(0.03)
				iteration -= 1
				print(Back.GREEN + '                                 ')
				time.sleep(0.03)
				iteration -= 1
				print(Back.CYAN + '                                 ')
				time.sleep(0.03)
				iteration -= 1
				print(Back.BLUE + '                                 ')
				time.sleep(0.03)
				iteration -= 1
				print(Back.MAGENTA + '                                 ' + Style.RESET_ALL)
				time.sleep(0.03)
				iteration -= 1
				if iteration == 0 or iteration < 0:
					print(Fore.GREEN + 'Test complited! Operation = 1' + Style.RESET_ALL)
		elif color_input == 2:
			while iteration > 0:
				import time
				print(Back.RED + '       ' + Back.GREEN + '       ' + Back.BLUE + '       ' +  Style.RESET_ALL)
				time.sleep(0.03)
				print(Back.RED + '       ' + Back.GREEN + '       ' + Back.BLUE + '       ' +  Style.RESET_ALL)
				time.sleep(0.03)
				print(Back.RED + '       ' + Back.GREEN + '       ' + Back.BLUE + '       ' +  Style.RESET_ALL)
				iteration -= 1
				if iteration == 0 or iteration < 0:
					print(Fore.GREEN + 'Test complited! Operation = 1' + Style.RESET_ALL)
		elif color_input == 3:
			while iteration > 0:
				import time
				iteration -= 5
				print(Back.LIGHTBLUE_EX + '      ' + Style.RESET_ALL + ' ' + Back.LIGHTBLUE_EX + '      ' + Style.RESET_ALL)
				print(Back.LIGHTBLUE_EX + '      ' + Style.RESET_ALL + ' ' + Back.LIGHTBLUE_EX + '      ' + Style.RESET_ALL)
				print(Back.LIGHTBLUE_EX + '      ' + Style.RESET_ALL + ' ' + Back.LIGHTBLUE_EX + '      ' + Style.RESET_ALL)
				print(Back.LIGHTBLUE_EX + '      ' + Style.RESET_ALL + ' ' + Back.LIGHTBLUE_EX + '      ' + Style.RESET_ALL)
				print('                                                                                                   ')
				iteration -= 10
				if iteration == 0 or iteration < 0:
					print(Fore.GREEN + 'Test complited! Operation = 1' + Style.RESET_ALL)
	elif os_choose == 1:
		print('Goodbye..')
		input('Press any key')
		break
		2 + 2