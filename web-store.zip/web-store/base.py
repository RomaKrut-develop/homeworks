purchase_data = [
    [1, 'USB wi-fi adapter', 200, 'electronics', '2015-9-15'],
    [2, 'Gaming Keyboard', 800, 'electronics', '2016-12-30'],
    [3, 'Shoes', 300, 'clothing', '2017-1-23'],
    [1, 'Iphone', 1200, 'electronics', '2015-11-12'],
    [4, 'Motherboard', 500, 'electronics', '2018-3-16']
]
def filter_purchases_by_category(purchase_data, category):
    return [purchase for purchase in purchase_data if purchase[3] == category]
filtered_purchases = filter_purchases_by_category(purchase_data, 'electronics')
print('Welcome to our store!')
print(filtered_purchases)
def calculate_total_spent_by_customer(purchase_data):
    total_spent = {}

    for purchase in purchase_data:
        customer_id = purchase[0]
        amount = purchase[2]
        if customer_id in total_spent:
            total_spent[customer_id] += amount
        else:
            total_spent[customer_id] = amount
    return [(customer_id, total) for customer_id, total in total_spent.items()]
total_spent_by_customer = calculate_total_spent_by_customer(purchase_data)
print(total_spent_by_customer)